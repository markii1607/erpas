/**

 * @fileoverview  Axis component.
 * @author NHN Ent.
 *         FE Development Lab <dl_javascript@nhnent.com>
 */

'use strict';

var chartConst = require('../../const');
var predicate = require('../../helpers/predicate');
var calculator = require('../../helpers/calculator');
var pluginFactory = require('../../factories/pluginFactory');
var renderUtil = require('../../helpers/renderUtil');
var snippet = require('tui-code-snippet');

var Axis = snippet.defineClass(/** @lends Axis.prototype */ {
    /**
     * Axis component.
     * @constructs Axis
     * @private
     * @param {object} params parameters
     *      @param {object} params.bound axis bound
     *      @param {object} params.theme axis theme
     *      @param {object} params.options axis options
     *      @param {object} params.dataProcessor data processor of chart
     *      @param {object} params.seriesType series type
     *      @param {boolean} params.isYAxis boolean value for axis is vertical or not
     */
    init: function(params) {
        /**
         * Axis view className
         * @type {string}
         */
        this.className = 'tui-chart-axis-area';

        /**
         * Data processor
         * @type {DataProcessor}
         */
        this.dataProcessor = params.dataProcessor;

        /**
         * Options
         * @type {object}
         */
        this.options = params.options || {};

        /**
         * Axis Theme
         * Use chart background theme object for render yAxis background on dynamicDataShifting chart
         * @type {object}
         */
        this.theme = snippet.extend({}, params.theme, {
            background: params.chartTheme.chart.background
        });

        /**
         * Whether label type axis or not.
         * @type {boolean}
         */
        this.isLabelAxis = false;

        /**
         * Whether vertical type or not.
         * @type {boolean}
         */
        this.isYAxis = params.isYAxis;

        /**
         * Whether data dynamic shifting or not.
         * @type {boolean}
         */
        this.shifting = params.shifting;

        /**
         * cached axis data
         * @type {object}
         */
        this.data = {};

        /**
         * layout bounds information for this components
         * @type {null|{dimension:{width:number, height:number}, position:{left:number, top:number, ?right:number}}}
         */
        this.layout = null;

        /**
         * dimension map for layout of chart
         * @type {null|object}
         */
        this.dimensionMap = null;

        /**
         * axis data map
         * @type {null|object}
         */
        this.axisDataMap = null;

        /**
         * Renderer
         * @type {object}
         */
        this.graphRenderer = pluginFactory.get(chartConst.COMPONENT_TYPE_RAPHAEL, 'axis');

        /**
         * Drawing type
         * @type {string}
         */
        this.drawingType = chartConst.COMPONENT_TYPE_RAPHAEL;

        /**
         * Paper additional width
         * @type {number}
         */
        this.paperAdditionalWidth = 0;

        /**
         * Paper additional height
         * @type {number}
         */
        this.paperAdditionalHeight = 0;

        /**
         * Raphael Element for axis background
         * We should caching this for prevent making background multiply
         * @type {Raphael.Element}
         */
        this._elBg = null;

        this.isRightYAxis = params.name === 'rightYAxis';
    },

    /**
     * Render vertical axis background
     * @private
     */
    _renderBackground: function() {
        var dimension = snippet.extend({}, this.layout.dimension);
        var position = snippet.extend({}, this.layout.position);

        if (this._elBg) {
            this._elBg.remove();
        }

        this._elBg = this.graphRenderer.renderBackground(this.paper, position, dimension, this.theme.background);
    },
    /**
     * Render child containers like title area, label area and tick area.
     * @param {number} size xAxis width or yAxis height
     * @param {number} tickCount tick count
     * @param {Array.<number|string>} categories categories
     * @param {number} additionalWidth additional width
     * @private
     */
    _renderChildContainers: function(size, tickCount, categories, additionalWidth) {
        var isYAxisLineType = this.isYAxis && this.data.aligned;
        var axisLimit = this.limitMap[this.dataProcessor.chartType];
        var isNegativeLimitChart = !this.data.limit && axisLimit && axisLimit.min < 0;
        var isBarChart = predicate.isBarTypeChart(this.dataProcessor.chartType);
        var seriesOption = this.dataProcessor.getOption('series') || {};
        var isDivergingOption = seriesOption.diverging;

        additionalWidth = additionalWidth || 0;

        if (this.isYAxis && !this.data.isPositionRight && !this.options.isCenter && this.shifting) {
            this._renderBackground();
        }

        this._renderTitleArea(size, additionalWidth);

        if (this.options.showLabel !== false) {
            this._renderLabelArea(size, tickCount, categories, additionalWidth);
        }

        if (!isYAxisLineType) {
            this._renderTickArea(size, tickCount, additionalWidth);
        }
        if (isNegativeLimitChart && isBarChart && !isDivergingOption) {
            this._renderNegativeStandardsLine(size, additionalWidth, this.dimensionMap.series, axisLimit);
        }
    },

    /**
     * Render divided xAxis if yAxis rendered in the center.
     * @param {{width: number, height:number}} dimension axis area width and height
     * @private
     */
    _renderDividedAxis: function(dimension) {
        var axisData = this.data;
        var lSideWidth = Math.round(dimension.width / 2);
        var rSideWidth = dimension.width - lSideWidth - 1;
        var tickCount = axisData.tickCount;
        var halfTickCount = parseInt(tickCount / 2, 10) + 1;
        var categories = axisData.labels;
        var lCategories = categories.slice(0, halfTickCount);
        var rCategories = categories.slice(halfTickCount - 1, tickCount);
        var tickInterval = lSideWidth / halfTickCount;
        var secondXAxisAdditionalPosition = lSideWidth + this.dimensionMap.yAxis.width - 1;

        this.paperAdditionalWidth = tickInterval;

        this._renderChildContainers(lSideWidth, halfTickCount, lCategories, 0);
        this._renderChildContainers(rSideWidth + 1, halfTickCount, rCategories,
            secondXAxisAdditionalPosition);
    },

    /**
     * Render single axis if not divided.
     * @param {{width: number, height: number}} dimension axis area dimension
     * @private
     */
    _renderNotDividedAxis: function(dimension) {
        var axisData = this.data;
        var isYAxis = this.isYAxis;
        var size = isYAxis ? dimension.height : dimension.width;
        var additionalSize = 0;

        if (axisData.positionRatio) {
            additionalSize = size * axisData.positionRatio;
        }

        this._renderChildContainers(size, axisData.tickCount, axisData.labels, additionalSize);
    },

    /**
     * Render axis area.
     * @private
     */
    _renderAxisArea: function() {
        var dimension = this.layout.dimension;
        var axisData = this.data;

        this.isLabelAxis = axisData.isLabelAxis;

        if (this.options.divided) {
            this.containerWidth = dimension.width + this.dimensionMap.yAxis.width;
            this._renderDividedAxis(dimension);
            dimension.width = this.containerWidth;
        } else {
            dimension.width += this.options.isCenter ? 1 : 0;
            this._renderNotDividedAxis(dimension);
        }
    },

    /**
     * Set data for rendering.
     * @param {{
     *      options: ?object,
     *      layout: {
     *          dimension: {width: number, height: number},
     *          position: {left: number, top: number}
     *      },
     *      dimensionMap: object,
     *      axisDataMap: object
     * }} data - bounds and scale data
     * @private
     */
    _setDataForRendering: function(data) {
        this.layout = data.layout;
        this.dimensionMap = data.dimensionMap;
        this.limitMap = data.limitMap;
        this.data = data.axisDataMap[this.componentName];
        this.options = this.data.options;
    },

    /**
     * @param {object} data - bounds and scale data
     */
    render: function(data) {
        this.paper = data.paper;
        this.axisSet = data.paper.set();

        this._setDataForRendering(data);
        this._renderAxisArea();
    },

    /**
     * Rerender axis component.
     * @param {object} data - bounds and scale data
     */
    rerender: function(data) {
        this.axisSet.remove();

        this.render(data);
    },

    /**
     * Resize axis component.
     * @param {object} data - bounds and scale data
     */
    resize: function(data) {
        this.rerender(data);
    },

    /**
     * Zoom.
     * @param {object} data - bounds and scale data
     */
    zoom: function(data) {
        this.rerender(data);
    },

    /**
     * get other side axis dimension
     * @returns {object}
     * @private
     */
    _getOtherSideDimension: function() {
        return this.dimensionMap[this.isYAxis ? 'xAxis' : 'yAxis'];
    },

    /**
     * Title area renderer
     * @param {number} size - area size
     * @param {number} additionalWidth - right side xAxis position
     * @private
     */
    _renderTitleArea: function(size, additionalWidth) {
        var title = this.options.title || {};
        var yAxisOption = this.dataProcessor.getOption('yAxis');
        var seriesOption = this.dataProcessor.getOption('series') || {};

        if (title.text) {
            this.graphRenderer.renderTitle(this.paper, {
                text: title.text,
                offset: title.offset,
                theme: this.theme.title,
                rotationInfo: {
                    isVertical: this.isYAxis,
                    isPositionRight: this.data.isPositionRight,
                    isCenter: this.options.isCenter,
                    isColumnType: predicate.isColumnTypeChart(
                        this.dataProcessor.chartType, this.dataProcessor.seriesTypes
                    ),
                    isDiverging: seriesOption.diverging,
                    isYAxisCenter: yAxisOption && yAxisOption.align === 'center'
                },
                layout: this.layout,
                areaSize: size,
                additionalWidth: additionalWidth,
                otherSideDimension: this._getOtherSideDimension(),
                tickCount: this.data.tickCount,
                set: this.axisSet
            });
        }
    },

    /**
     * Render tick line.
     * @param {number} areaSize - width or height
     * @param {boolean} isNotDividedXAxis - whether is not divided x axis or not.
     * @param {number} additionalSize - additional size
     * @private
     */
    _renderTickLine: function(areaSize, isNotDividedXAxis, additionalSize) {
        this.graphRenderer.renderTickLine({
            areaSize: areaSize,
            additionalSize: additionalSize,
            additionalWidth: this.paperAdditionalWidth,
            additionalHeight: this.paperAdditionalHeight,
            isPositionRight: this.data.isPositionRight,
            isCenter: this.data.options.isCenter,
            isNotDividedXAxis: isNotDividedXAxis,
            isVertical: this.isYAxis,
            tickColor: this.theme.tickColor,
            layout: this.layout,
            paper: this.paper,
            set: this.axisSet
        });
    },

    /**
     * Render ticks.
     * @param {number} size - width or height
     * @param {number} tickCount - tick count
     * @param {boolean} isNotDividedXAxis - whether is not divided x axis or not.
     * @param {number} [additionalSize] - additional size
     * @private
     */
    _renderTicks: function(size, tickCount, isNotDividedXAxis, additionalSize) {
        var tickColor = this.theme.tickColor;
        var axisData = this.data;
        var remainLastBlockIntervalPosition = (axisData.remainLastBlockInterval) ? size : 0;
        var sizeRatio = axisData.sizeRatio || 1;
        var isYAxis = this.isYAxis;
        var isCenter = this.data.options.isCenter;
        var isDivided = this.data.options.divided;
        var isPositionRight = this.data.isPositionRight;
        var positions = calculator.makeTickPixelPositions(
            (size * sizeRatio),
            tickCount,
            0,
            remainLastBlockIntervalPosition
        );
        var additionalHeight = this.paperAdditionalHeight + 1;
        var additionalWidth = this.paperAdditionalWidth;
        var positionLength = remainLastBlockIntervalPosition ? axisData.tickCount + 1 : axisData.tickCount;

        positions.length = positionLength;

        this.graphRenderer.renderTicks({
            paper: this.paper,
            layout: this.layout,
            positions: positions,
            isVertical: isYAxis,
            isCenter: isCenter,
            isDivided: isDivided,
            additionalSize: additionalSize,
            additionalWidth: additionalWidth,
            additionalHeight: additionalHeight,
            otherSideDimension: this._getOtherSideDimension(),
            isPositionRight: isPositionRight,
            tickColor: tickColor,
            set: this.axisSet
        });
    },

    _renderNegativeStandardsLine: function(size, additionalSize, seriesDimension, axisLimit) {
        this.graphRenderer.renderStandardLine({
            areaSize: size,
            isVertical: this.isYAxis,
            layout: this.layout,
            paper: this.paper,
            set: this.axisSet,
            seriesDimension: seriesDimension,
            axisLimit: axisLimit
        });
    },

    /**
     * Render tick area.
     * @param {number} size - width or height
     * @param {number} tickCount - tick count
     * @param {number} [additionalSize] - additional size (width or height)
     * @private
     */
    _renderTickArea: function(size, tickCount, additionalSize) {
        var isNotDividedXAxis = !this.isYAxis && !this.options.divided;

        this._renderTickLine(size, isNotDividedXAxis, (additionalSize || 0));
        this._renderTicks(size, tickCount, isNotDividedXAxis, (additionalSize || 0));
    },

    /**
     * Render label area.
     * @param {number} size label area size
     * @param {number} tickCount tick count
     * @param {Array.<string>} categories categories
     * @param {number} [additionalSize] additional size (width or height)
     * @private
     */
    _renderLabelArea: function(size, tickCount, categories, additionalSize) {
        var sizeRatio = this.data.sizeRatio || 1;
        var axisData = this.data;
        var remainLastBlockIntervalPosition = (axisData.remainLastBlockInterval) ? size : 0;
        var tickPixelPositions = calculator.makeTickPixelPositions(
            (size * sizeRatio),
            tickCount,
            0,
            remainLastBlockIntervalPosition
        );
        var labelDistance = tickPixelPositions[1] - tickPixelPositions[0];

        this._renderLabels(tickPixelPositions, categories, labelDistance, (additionalSize || 0));
    },

    /**
     * Make html of rotation labels.
     * @param {Array.<object>} positions label position array
     * @param {string[]} categories categories
     * @param {number} labelSize label size
     * @param {number} additionalSize additional size
     * @private
     */
    _renderRotationLabels: function(positions, categories, labelSize, additionalSize) {
        var renderer = this.graphRenderer;
        var isYAxis = this.isYAxis;
        var theme = this.theme.label;
        var degree = this.data.degree;
        var halfWidth = labelSize / 2;
        var edgeAlignWidth = labelSize / chartConst.AXIS_EDGE_RATIO;
        var horizontalTop = this.layout.position.top + chartConst.X_AXIS_LABEL_PADDING;
        var baseLeft = this.layout.position.left;
        var labelMargin = this.options.labelMargin || 0;

        snippet.forEach(positions, function(position, index) {
            var labelPosition = position + (additionalSize || 0);
            var positionTopAndLeft = {};

            if (isYAxis) {
                positionTopAndLeft.top = labelPosition + halfWidth;
                positionTopAndLeft.left = labelSize + labelMargin;
            } else {
                positionTopAndLeft.top = horizontalTop + labelMargin;
                positionTopAndLeft.left = baseLeft + labelPosition + edgeAlignWidth;
            }

            renderer.renderRotatedLabel({
                degree: degree,
                labelText: categories[index],
                paper: this.paper,
                positionTopAndLeft: positionTopAndLeft,
                set: this.axisSet,
                theme: theme
            });
        }, this);
    },

    /**
     * Make html of normal labels.
     * @param {Array.<object>} positions label position array
     * @param {string[]} categories categories
     * @param {number} labelSize label size
     * @param {number} additionalSize additional size
     * @private
     */
    _renderNormalLabels: function(positions, categories, labelSize, additionalSize) {
        var renderer = this.graphRenderer;
        var isYAxis = this.isYAxis;
        var isPositionRight = this.data.isPositionRight;
        var isCategoryLabel = this.isLabelAxis;
        var theme = this.theme.label;
        var dataProcessor = this.dataProcessor;
        var isLineTypeChart = predicate.isLineTypeChart(dataProcessor.chartType, dataProcessor.seriesTypes);
        var isPointOnColumn = isLineTypeChart && this.options.pointOnColumn;
        var layout = this.layout;
        var labelMargin = this.options.labelMargin || 0;

        snippet.forEach(positions, function(position, index) {
            var labelPosition = position + additionalSize;
            var halfLabelDistance = labelSize / 2;
            var positionTopAndLeft = {};
            /*
             * to prevent printing `undefined` text, when category label is not set
             */
            if (labelPosition < 0) {
                return;
            }

            if (isYAxis) {
                positionTopAndLeft = this._getYAxisLabelPosition(layout, {
                    labelPosition: labelPosition,
                    isCategoryLabel: isCategoryLabel,
                    halfLabelDistance: halfLabelDistance,
                    isPositionRight: isPositionRight
                });
            } else {
                positionTopAndLeft = this._getXAxisLabelPosition(layout, {
                    labelMargin: labelMargin,
                    labelHeight: renderUtil.getRenderedLabelsMaxHeight(categories, theme),
                    labelPosition: labelPosition,
                    isCategoryLabel: isCategoryLabel,
                    isLineTypeChart: isLineTypeChart,
                    isPointOnColumn: isPointOnColumn,
                    halfLabelDistance: halfLabelDistance
                });
            }

            positionTopAndLeft.top = Math.round(positionTopAndLeft.top);
            positionTopAndLeft.left = Math.round(positionTopAndLeft.left);

            renderer.renderLabel({
                isPositionRight: isPositionRight,
                isVertical: isYAxis,
                isCenter: this.options.isCenter,
                labelSize: labelSize,
                labelText: categories[index],
                paper: this.paper,
                positionTopAndLeft: positionTopAndLeft,
                set: this.axisSet,
                theme: theme
            });
        }, this);
    },

    /**
     * @param {object} layout - axis dimension, position
     * @param {object} params - optional data needed to render axis labels
     * @returns {object} top, left positon of y axis
     */
    _getYAxisLabelPosition: function(layout, params) {
        var labelTopPosition = params.labelPosition;
        var labelLeftPosition;

        if (params.isCategoryLabel) {
            labelTopPosition += params.halfLabelDistance + layout.position.top;
        } else {
            labelTopPosition = layout.dimension.height + layout.position.top - labelTopPosition;
        }

        if (params.isPositionRight) {
            labelLeftPosition = layout.position.left + layout.dimension.width;
        } else if (this.options.isCenter) {
            labelLeftPosition = layout.position.left + (layout.dimension.width / 2);
        } else {
            labelLeftPosition = layout.position.left;
        }

        return {
            top: labelTopPosition,
            left: labelLeftPosition
        };
    },

    /**
     * @param {object} layout - axis dimension, position
     * @param {object} params - optional data needed to render axis labels
     * @returns {object} top, left positon of y axis
     */
    _getXAxisLabelPosition: function(layout, params) {
        var labelTopPosition = layout.position.top
            + chartConst.X_AXIS_LABEL_PADDING
            + params.labelMargin + (params.labelHeight / 2);
        var labelLeftPosition = params.labelPosition + layout.position.left;

        if (params.isCategoryLabel) {
            if (!params.isLineTypeChart || params.isPointOnColumn) {
                labelLeftPosition += params.halfLabelDistance;
            }
        }

        return {
            top: labelTopPosition,
            left: labelLeftPosition
        };
    },

    /**
     * Make labels html.
     * @param {Array.<object>} positions - positions for labels
     * @param {Array.<string>} categories - categories
     * @param {number} labelSize label size
     * @param {number} additionalSize additional size
     * @private
     */
    _renderLabels: function(positions, categories, labelSize, additionalSize) {
        var isRotationlessXAxis = !this.isYAxis && this.isLabelAxis && (this.options.rotateLabel === false);
        var hasRotatedXAxisLabel = this.componentName === 'xAxis' && this.data.degree;
        var axisLabels;

        if (isRotationlessXAxis) {
            axisLabels = this.data.multilineLabels;
        } else {
            axisLabels = categories;
        }

        if (axisLabels.length) {
            positions.length = axisLabels.length;
        }

        axisLabels = renderUtil.addPrefixSuffix(axisLabels, this.options.prefix, this.options.suffix);

        if (hasRotatedXAxisLabel) {
            this._renderRotationLabels(positions, axisLabels, labelSize, additionalSize);
        } else {
            this._renderNormalLabels(positions, axisLabels, labelSize, additionalSize);
        }
    },
    /**
     * Animate axis for adding data
     * @param {object} data rendering data
     */
    animateForAddingData: function(data) {
        if (!this.isYAxis) {
            this.graphRenderer.animateForAddingData(data.tickSize);
        }
    }
});

/**
 * Factory for Axis
 * @param {object} axisParam parameter
 * @returns {object}
 * @ignore
 */
function axisFactory(axisParam) {
    var chartType = axisParam.chartOptions.chartType;
    var name = axisParam.name;

    axisParam.isYAxis = (name === 'yAxis' || name === 'rightYAxis');
    axisParam.shifting = axisParam.chartOptions.series.shifting;

    // In combo chart, the theme is divided into series name considering two YAxis(yAxis and rightYAxis)
    // @todo change theme structure so that access theme by axis type, not considering chart type
    //     like theme.xAxis, theme.yAxis, theme.rightYAxis
    if (chartType === 'combo') {
        if (axisParam.isYAxis) {
            axisParam.theme = axisParam.theme[axisParam.seriesTypes[0]];
        } else if (name === 'rightYAxis') {
            axisParam.componentType = 'yAxis';
            axisParam.theme = axisParam.theme[axisParam.seriesTypes[1]];
            axisParam.index = 1;
        }
    // @todo I do not know why the single type chart with yAxis branches once again as the chart name inside it. I feel inconsistent
    } else if (axisParam.isYAxis) {
        axisParam.theme = axisParam.theme[chartType];
    // single chart, xAxis
    } else {
        axisParam.theme = axisParam.theme;
    }

    return new Axis(axisParam);
}

axisFactory.componentType = 'axis';
axisFactory.Axis = Axis;

module.exports = axisFactory;
