### Code table of [Thailand map](../../maps/thailand.js)

|Code|Name|
|---|---|
|TH-KM|Krung Thep Maha Nakhon  (Bangkok)|
|TH-SP|Samut Prakan|
|TH-NB|Nonthaburi|
|TH-PT|Pathum Thani|
|TH-PS|Phra Nakhon Si Ayutthaya|
|TH-AT|Ang Thong|
|TH-LO|Lop Buri|
|TH-SI|Sing Buri|
|TH-CN|Chai Nat|
|TH-SB|Saraburi|
|TH-CB|Chon Buri|
|TH-RY|Rayong|
|TH-CT|Chanthaburi|
|TH-TT|Trat|
|TH-CS|Chachoengsao|
|TH-PB|Prachin Buri|
|TH-NN|Nakhon Nayok|
|TH-SK|Sa Kaeo|
|TH-NR|Nakhon Ratchasima|
|TH-BR|Buri Ram|
|TH-SN|Surin|
|TH-SS|Si Sa Ket|
|TH-UR|Ubon Ratchathani|
|TH-YT|Yasothon|
|TH-CY|Chaiyaphum|
|TH-AC|Amnat Charoen|
|TH-BK|Bueng Kan|
|TH-NL|Nong Bua Lam Phu|
|TH-KK|Khon Kaen|
|TH-UD|Udon Thani|
|TH-LE|Loei|
|TH-NK|Nong Khai|
|TH-MS|Maha Sarakham|
|TH-RE|Roi Et|
|TH-KS|Kalasin|
|TH-SO|Sakon Nakhon|
|TH-NP|Nakhon Phanom|
|TH-MD|Mukdahan|
|TH-CM|Chiang Mai|
|TH-LH|Lamphun|
|TH-LP|Lampang|
|TH-UA|Uttaradit|
|TH-PR|Phrae|
|TH-NA|Nan|
|TH-PY|Phayao|
|TH-CR|Chiang Rai|
|TH-MH|Mae Hong Son|
|TH-NS|Nakhon Sawan|
|TH-UT|Uthai Thani|
|TH-KP|Kamphaeng Phet|
|TH-TK|Tak|
|TH-ST|Sukhothai|
|TH-PL|Phitsanulok|
|TH-PC|Phichit|
|TH-PN|Phetchabun|
|TH-RT|Ratchaburi|
|TH-KC|Kanchanaburi|
|TH-SH|Suphan Buri|
|TH-NM|Nakhon Pathom|
|TH-SM|Samut Sakhon|
|TH-SR|Samut Songkhram|
|TH-PH|Phetchaburi|
|TH-PK|Prachuap Khiri Khan|
|TH-NT|Nakhon Si Thammarat|
|TH-KB|Krabi|
|TH-PG|Phangnga|
|TH-PU|Phuket|
|TH-SU|Surat Thani|
|TH-RN|Ranong|
|TH-CP|Chumphon|
|TH-SL|Songkhla|
|TH-SA|Satun|
|TH-TR|Trang|
|TH-PA|Phatthalung|
|TH-PI|Pattani|
|TH-YL|Yala|
|TH-NW|Narathiwat|
|TH-LS|Lake Songkhla|
