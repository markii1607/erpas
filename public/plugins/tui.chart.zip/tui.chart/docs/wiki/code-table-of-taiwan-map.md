### Code table of [Taiwan map](../../maps/taiwan.js)

|Code|Name|
|---|---|
|TW-LCG|Lienchiang|
|TW-KNM|Kinmen|
|TW-PEN|Penghu|
|TW-TTT|Taitung|
|TW-YUN|Yunlin|
|TW-TXQ|Taichung City|
|TW-NAN|Nantou|
|TW-HUA|Hualien|
|TW-CYI|Chiayi City|
|TW-CYQ|Chiayi|
|TW-CHA|Changhua|
|TW-TAO|Taoyuan|
|TW-TPQ|New Taipei City|
|TW-TPE|Taipei City|
|TW-MIA|Miaoli|
|TW-KLG|Keelung City|
|TW-ILA|Yilan|
|TW-HSZ|Hsinchu|
|TW-HSQ|Hsinchu City|
|TW-TNQ|Tainan City|
|TW-PIF|Pingtung|
|TW-KHQ|Kaohsiung City|
